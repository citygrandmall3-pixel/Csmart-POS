(function () {
    'use strict';

    const draftBtn = document.getElementById('btnShowDraftSales');
    if (!draftBtn) return;

    let isLoadingDrafts = false;

    function notify(message, type) {
        if (typeof window.showAppNotification === 'function') {
            window.showAppNotification(String(message ?? ''), type || 'info');
        } else {
            console.error('[Csmart POS drafts] Notification system is not ready:', message);
        }
    }

    async function appPrompt(message) {
        if (typeof window.showAppPrompt !== 'function') {
            notify('نافذة الإدخال الموحدة غير جاهزة. حدّث الصفحة وحاول مرة أخرى.', 'error');
            return null;
        }
        return window.showAppPrompt(String(message ?? ''));
    }

    async function appConfirm(message) {
        if (typeof window.showAppConfirm !== 'function') {
            notify('نافذة التأكيد الموحدة غير جاهزة. حدّث الصفحة وحاول مرة أخرى.', 'error');
            return false;
        }
        return window.showAppConfirm(String(message ?? ''));
    }

    function getCurrentSaleId() {
        try {
            if (typeof currentSaleId !== 'undefined' && currentSaleId) {
                const id = Number(currentSaleId);
                return Number.isFinite(id) && id > 0 ? id : null;
            }
        } catch (e) {}
        return null;
    }

    draftBtn.addEventListener('click', async function () {
        if (isLoadingDrafts) return;
        isLoadingDrafts = true;
        draftBtn.disabled = true;

        const activeSaleId = getCurrentSaleId();

        try {
            const [sessionResponse, salesResponse] = await Promise.all([
                fetch('/api/cashier-sessions/current', { credentials: 'same-origin' }),
                fetch('/api/sales', { credentials: 'same-origin' })
            ]);

            const [sessionData, salesData] = await Promise.all([
                sessionResponse.json(),
                salesResponse.json()
            ]);

            if (!sessionResponse.ok || !sessionData.ok) {
                notify('تعذر معرفة الوردية الحالية.', 'error');
                return;
            }

            if (!sessionData.session) {
                notify('لا توجد وردية مفتوحة حاليًا.', 'warning');
                return;
            }

            if (!salesResponse.ok || !salesData.ok) {
                notify(salesData.error || 'تعذر تحميل المسودات.', 'error');
                return;
            }

            const sessionId = Number(sessionData.session.id);
            const drafts = (salesData.rows || []).filter(sale =>
                sale.status === 'draft' && Number(sale.session_id) === sessionId
            );

            if (!drafts.length) {
                notify('لا توجد مسودات في ورديتك الحالية.', 'info');
                return;
            }

            const list = drafts.map((sale, index) => {
                const isCurrent = activeSaleId === Number(sale.id);
                const currentMark = isCurrent ? ' — الفاتورة المفتوحة حاليًا' : '';
                return (index + 1) + ') ' +
                    (sale.invoice_no || 'فاتورة #' + sale.id) +
                    ' — ' + (sale.invoice_date || '') +
                    ' — ' + Number(sale.grand_total || 0).toFixed(2) + ' ل.س' + currentMark;
            }).join('\n');

            const answer = await appPrompt(
                'مسودات ورديتك الحالية (' + drafts.length + '):\n\n' + list +
                '\n\nاكتب رقم المسودة لعرض خياراتها، أو اضغط إلغاء للعودة إلى البيع.'
            );

            if (answer === null || String(answer).trim() === '') return;

            const choice = Number(answer);
            if (!Number.isInteger(choice) || choice < 1 || choice > drafts.length) {
                notify('رقم غير صحيح.', 'warning');
                return;
            }

            const sale = drafts[choice - 1];
            const selectedSaleId = Number(sale.id);

            if (activeSaleId && selectedSaleId === activeSaleId) {
                notify('هذه هي الفاتورة المفتوحة حاليًا بالفعل؛ لم يتم تغييرها.', 'info');
                return;
            }

            if (activeSaleId) {
                const action = await appPrompt(
                    'الفاتورة: ' + (sale.invoice_no || sale.id) +
                    '\nالإجمالي: ' + Number(sale.grand_total || 0).toFixed(2) + ' ل.س' +
                    '\n\nالفاتورة الحالية محفوظة كما هي.' +
                    '\nلاستئناف هذه المسودة، علّق الفاتورة الحالية أولًا.' +
                    '\nاكتب 2 لحذف المسودة نهائيًا، أو اضغط إلغاء للعودة.'
                );
                if (action === null || String(action).trim() === '') return;
                if (String(action).trim() !== '2') {
                    notify('لا يمكن استئناف مسودة أثناء وجود فاتورة بيع مفتوحة. علّق الفاتورة الحالية أولًا.', 'warning');
                    return;
                }
            } else {
                const action = await appPrompt(
                    'الفاتورة: ' + (sale.invoice_no || sale.id) +
                    '\n\nاكتب 1 لاستئناف المسودة' +
                    '\nاكتب 2 لحذفها نهائيًا، أو اضغط إلغاء للعودة:'
                );

                if (action === null || String(action).trim() === '') return;

                if (String(action).trim() === '1') {
                    if (typeof loadSaleItems !== 'function') {
                        notify('تعذر تحميل أصناف المسودة؛ دالة تحميل الفاتورة غير جاهزة.', 'error');
                        return;
                    }

                    currentSaleId = selectedSaleId;
                    currentSaleStatus = 'draft';
                    try {
                        sessionStorage.setItem('kstore_current_sale_id', String(selectedSaleId));
                    } catch (e) {}

                    await loadSaleItems();
                    notify('تم فتح المسودة دون اعتمادها.', 'success');
                    return;
                }

                if (String(action).trim() !== '2') {
                    notify('اختيار غير صحيح.', 'warning');
                    return;
                }
            }

            const confirmed = await appConfirm(
                'تحذير: سيتم حذف المسودة وأصنافها وتفاصيل توصيلها نهائيًا.\nهل تريد المتابعة؟'
            );
            if (!confirmed) return;

            const deleteResponse = await fetch('/api/sales/' + selectedSaleId, {
                method: 'DELETE',
                credentials: 'same-origin'
            });
            const deleteData = await deleteResponse.json();

            if (!deleteResponse.ok || !deleteData.ok) {
                notify(deleteData.error || 'فشل حذف المسودة.', 'error');
                return;
            }

            notify('تم حذف المسودة نهائيًا.', 'success');
        } catch (error) {
            console.error('[Csmart POS drafts]', error);
            notify('حدث خطأ أثناء معالجة المسودات: ' + (error?.message || 'خطأ غير معروف'), 'error');
        } finally {
            isLoadingDrafts = false;
            draftBtn.disabled = false;
        }
    });
})();
