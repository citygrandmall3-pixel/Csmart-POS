(function () {
  'use strict';

  const $ = id => document.getElementById(id);
  const customerInput = $('posCustomerSearch');
  const customerResults = $('posCustomerResults');
  const productSearch = $('posProductSearch');
  const categoryTop = $('posProductCategoryFilter');
  const categorySide = $('productCategorySelect');
  const productContainer = $('productCatalogList');
  const historyModal = $('posSalesHistoryModal');
  const historySearch = $('posSalesHistorySearch');
  const historyRows = $('posSalesHistoryRows');
  const historyMessage = $('posSalesHistoryMessage');
  let customerTimer = null;
  let historyData = [];
  let selectedCustomer = null;
  let observer = null;

  function notify(message) {
    if (typeof window.showAppAlert === 'function') window.showAppAlert(String(message));
    else window.alert(String(message));
  }

  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }

  function setHeaderCustomer(customer) {
    selectedCustomer = customer ? { id: Number(customer.id), name: String(customer.name || ''), phone: String(customer.phone || '') } : null;
    window.posSelectedCustomer = selectedCustomer;
    const label = $('headerCustomerName');
    if (label) label.textContent = selectedCustomer ? selectedCustomer.name : 'عميل نقدي';
    if (customerInput) customerInput.value = selectedCustomer ? selectedCustomer.name : '';
  }

  function closeCustomerResults() {
    if (customerResults) {
      customerResults.style.display = 'none';
      customerResults.replaceChildren();
    }
  }

  async function saveCustomerToCurrentSale(customer) {
    if (typeof currentSaleId === 'undefined' || !currentSaleId) return true;
    if (typeof currentSaleStatus !== 'undefined' && currentSaleStatus !== 'draft') {
      notify('لا يمكن تغيير العميل في فاتورة معتمدة.');
      return false;
    }
    const response = await fetch('/api/sales/' + encodeURIComponent(currentSaleId), {
      method: 'PUT', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ customer_id: customer ? Number(customer.id) : null })
    });
    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || 'تعذر حفظ العميل للفاتورة.');
    return true;
  }

  async function chooseCustomer(customer) {
    try {
      if (!(await saveCustomerToCurrentSale(customer))) return;
      setHeaderCustomer(customer);
      closeCustomerResults();
      if (customer) notify('تم اختيار العميل للفاتورة.');
    } catch (error) {
      notify(error.message || 'تعذر اختيار العميل.');
    }
  }

  function renderCustomerResults(partners) {
    if (!customerResults) return;
    customerResults.replaceChildren();
    const cash = document.createElement('button');
    cash.type = 'button';
    cash.className = 'pos-customer-option';
    cash.textContent = 'عميل نقدي (مسح اختيار العميل)';
    cash.addEventListener('click', () => chooseCustomer(null));
    customerResults.appendChild(cash);
    if (!partners.length) {
      const empty = document.createElement('div');
      empty.className = 'pos-customer-empty';
      empty.textContent = 'لا يوجد عملاء مطابقون';
      customerResults.appendChild(empty);
    } else {
      partners.forEach(partner => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'pos-customer-option';
        button.textContent = partner.name + (partner.phone ? ' — ' + partner.phone : '');
        button.addEventListener('click', () => chooseCustomer(partner));
        customerResults.appendChild(button);
      });
    }
    customerResults.style.display = 'block';
  }

  async function searchCustomers(query) {
    if (!customerResults) return;
    if (!query) { closeCustomerResults(); return; }
    try {
      const response = await fetch('/api/partners?q=' + encodeURIComponent(query), {
        credentials: 'same-origin', headers: { 'Accept': 'application/json' }
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'تعذر البحث عن العملاء.');
      const partners = (Array.isArray(data.partners) ? data.partners : []).filter(p =>
        p.partner_type === 'customer' && Number(p.is_active) === 1
      );
      renderCustomerResults(partners.slice(0, 30));
    } catch (error) {
      customerResults.textContent = error.message || 'تعذر البحث عن العملاء.';
      customerResults.style.display = 'block';
    }
  }

  function normalize(value) {
    return String(value || '').toLocaleLowerCase('ar').replace(/[ًٌٍَُِّْـ]/g, '').trim();
  }

  function applyProductFilters() {
    if (!productContainer) return;
    const query = normalize(productSearch && productSearch.value);
    const category = (categoryTop && categoryTop.value) || (categorySide && categorySide.value) || 'all';
    let visible = 0;
    productContainer.querySelectorAll('[data-category-id]').forEach(card => {
      const matchesCategory = category === 'all' || String(card.dataset.categoryId || '') === String(category);
      const searchValue = normalize(card.dataset.searchText || card.textContent);
      const matchesQuery = !query || searchValue.includes(query);
      const show = matchesCategory && matchesQuery;
      card.style.display = show ? '' : 'none';
      if (show) visible++;
    });
    const status = $('posProductSearchStatus');
    if (status) status.textContent = query ? ('النتائج المطابقة: ' + visible) : '';
  }

  function populateTopCategories() {
    if (!categoryTop) return;
    const fill = source => {
      if (!source) return;
      const current = source.value || 'all';
      categoryTop.replaceChildren(new Option('كل التصنيفات', 'all'));
      Array.from(source.options).slice(1).forEach(option => categoryTop.add(new Option(option.text, option.value)));
      categoryTop.value = Array.from(categoryTop.options).some(o => o.value === current) ? current : 'all';
    };
    if (categorySide && categorySide.options.length > 1) fill(categorySide);
    else fetch('/api/product-categories', { credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
      .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
      .then(data => {
        categoryTop.replaceChildren(new Option('كل التصنيفات', 'all'));
        (Array.isArray(data.items) ? data.items : []).filter(x => Number(x.is_active) !== 0)
          .forEach(x => categoryTop.add(new Option(x.name, String(x.id))));
      }).catch(error => console.warn('[POS] تعذر تحميل تصنيفات شريط الأدوات', error));
  }

  function setCategory(value, source) {
    const selected = value || 'all';
    if (categoryTop && source !== categoryTop) categoryTop.value = selected;
    if (categorySide && source !== categorySide) categorySide.value = selected;
    applyProductFilters();
  }

  function focusProductSearch() {
    if (productSearch) {
      productSearch.focus();
      productSearch.select();
    }
    const catalog = $('productCatalogList');
    if (catalog) catalog.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }

  function filterProductsAndEnter(event) {
    if (event.key !== 'Enter' || !productContainer) return;
    const visible = Array.from(productContainer.querySelectorAll('[data-category-id]')).filter(card => card.style.display !== 'none');
    if (visible.length === 1) {
      event.preventDefault();
      visible[0].click();
    } else if (visible.length > 1) {
      const query = normalize(productSearch.value);
      const exact = visible.filter(card => normalize(card.dataset.searchText).split(/\s+/).includes(query));
      if (query && exact.length === 1) {
        event.preventDefault();
        exact[0].click();
      }
    }
  }

  function renderHistory(rows) {
    if (!historyRows) return;
    const query = normalize(historySearch && historySearch.value);
    const filtered = (rows || []).filter(sale => normalize([
      sale.invoice_no, sale.customer_name, sale.invoice_date, sale.id, sale.status
    ].join(' ')).includes(query)).slice(0, 250);
    historyRows.innerHTML = filtered.map(sale => {
      const status = sale.status === 'draft' ? 'مسودة' : sale.status === 'approved' ? 'معتمدة' : (sale.status || '—');
      return '<tr><td>' + esc(sale.invoice_no || ('#' + sale.id)) + '</td><td>' + esc(sale.invoice_date || '') + '</td><td>' + esc(sale.customer_name || 'عميل نقدي') + '</td><td>' + Number(sale.grand_total || 0).toLocaleString('en-US') + ' ل.س</td><td>' + esc(status) + '</td><td><button type="button" class="pos-history-open" data-sale-id="' + Number(sale.id) + '">عرض الفاتورة</button></td></tr>';
    }).join('');
    if (historyMessage) historyMessage.textContent = filtered.length ? ('الفواتير المعروضة: ' + filtered.length) : 'لا توجد فواتير مطابقة.';
  }

  async function openSalesHistory() {
    if (!historyModal) return;
    historyModal.style.display = 'flex';
    if (historyMessage) historyMessage.textContent = 'جارٍ تحميل سجل الفواتير...';
    if (historyRows) historyRows.innerHTML = '';
    try {
      const response = await fetch('/api/sales', { credentials: 'same-origin', headers: { 'Accept': 'application/json' } });
      const data = await response.json();
      if (!response.ok || !data.ok) throw new Error(data.error || 'تعذر تحميل سجل الفواتير.');
      historyData = Array.isArray(data.rows) ? data.rows : [];
      renderHistory(historyData);
      if (historyMessage && historyData.length > 250) historyMessage.textContent += ' — يعرض آخر 250 نتيجة كحد أقصى.';
    } catch (error) {
      if (historyMessage) historyMessage.textContent = error.message || 'حدث خطأ أثناء تحميل السجل.';
    }
    if (historySearch) historySearch.focus();
  }

  async function openHistorySale(saleId) {
    const targetId = Number(saleId);
    if (!Number.isInteger(targetId) || targetId <= 0) return;
    if (typeof currentSaleId !== 'undefined' && currentSaleId && Number(currentSaleId) !== targetId && typeof currentSaleStatus !== 'undefined' && currentSaleStatus === 'draft') {
      const proceed = await window.showAppConfirm('ستنتقل إلى فاتورة أخرى. ستبقى المسودة الحالية محفوظة ويمكن الرجوع إليها من السجل. هل تريد المتابعة؟');
      if (!proceed) return;
    }
    try {
      const response = await fetch('/api/sales/' + targetId + '/items', { credentials: 'same-origin' });
      const data = await response.json();
      if (!response.ok || !data.ok) throw new Error(data.error || 'تعذر فتح الفاتورة.');
      currentSaleId = targetId;
      currentSaleStatus = data.status || null;
      try { sessionStorage.setItem('kstore_current_sale_id', String(targetId)); } catch (e) {}
      setHeaderCustomer(data.customer_id ? { id: data.customer_id, name: data.customer_name || '', phone: '' } : null);
      if (typeof loadSaleItems === 'function') await loadSaleItems();
      historyModal.style.display = 'none';
      if (currentSaleStatus !== 'draft') notify('تم فتح الفاتورة للعرض فقط؛ الفواتير المعتمدة لا تقبل تعديل الأصناف.');
    } catch (error) {
      notify(error.message || 'تعذر فتح الفاتورة.');
    }
  }

  function bind() {
    if (customerInput) {
      customerInput.addEventListener('input', function () {
        clearTimeout(customerTimer);
        const q = customerInput.value.trim();
        if (!q) { closeCustomerResults(); return; }
        customerTimer = setTimeout(() => searchCustomers(q), 220);
      });
      customerInput.addEventListener('keydown', event => {
        if (event.key === 'Escape') closeCustomerResults();
        if (event.key === 'Enter') {
          const first = customerResults && customerResults.querySelector('.pos-customer-option:not(:first-child)');
          if (first) { event.preventDefault(); first.click(); }
        }
      });
    }
    if (productSearch) {
      productSearch.addEventListener('input', applyProductFilters);
      productSearch.addEventListener('keydown', filterProductsAndEnter);
    }
    if (categoryTop) categoryTop.addEventListener('change', () => setCategory(categoryTop.value, categoryTop));
    if (categorySide) categorySide.addEventListener('change', () => setCategory(categorySide.value, categorySide));
    const addButton = $('posAddProductButton');
    if (addButton) addButton.addEventListener('click', focusProductSearch);
    const historyButton = $('posShowSalesHistoryButton');
    if (historyButton) historyButton.addEventListener('click', openSalesHistory);
    const closeHistory = $('posSalesHistoryClose');
    if (closeHistory) closeHistory.addEventListener('click', () => { historyModal.style.display = 'none'; });
    if (historyModal) {
      historyModal.addEventListener('click', event => {
        if (event.target === historyModal) historyModal.style.display = 'none';
        const button = event.target.closest('.pos-history-open');
        if (button) openHistorySale(button.dataset.saleId);
      });
    }
    if (historySearch) historySearch.addEventListener('input', () => renderHistory(historyData));
    document.addEventListener('keydown', event => {
      if (event.key === 'F2' && !event.repeat) { event.preventDefault(); focusProductSearch(); }
      if (event.key === 'F3' && !event.repeat) { event.preventDefault(); if (customerInput) { customerInput.focus(); customerInput.select(); } }
      if (event.key === 'Escape' && historyModal && historyModal.style.display === 'flex') historyModal.style.display = 'none';
      if (event.key === 'Escape') closeCustomerResults();
    });
    document.addEventListener('click', event => {
      if (customerResults && !event.target.closest('.k-header-center')) closeCustomerResults();
    });
    if (productContainer && window.MutationObserver) {
      observer = new MutationObserver(applyProductFilters);
      observer.observe(productContainer, { childList: true, subtree: true });
    }
    populateTopCategories();
    if (categorySide && categorySide.options.length > 1) setCategory(categorySide.value, categorySide);
    if (typeof currentSaleId !== 'undefined' && currentSaleId) {
      fetch('/api/sales/' + encodeURIComponent(currentSaleId) + '/items', {credentials:'same-origin'})
        .then(response => response.json())
        .then(data => {
          if (data && data.ok && data.customer_id) setHeaderCustomer({id:data.customer_id, name:data.customer_name || '', phone:''});
        })
        .catch(error => console.warn('[POS] تعذر استعادة العميل الحالي في شريط البحث', error));
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind, { once: true });
  else bind();

  window.posSetHeaderCustomer = setHeaderCustomer;
  window.posOpenSalesHistory = openSalesHistory;
})();
