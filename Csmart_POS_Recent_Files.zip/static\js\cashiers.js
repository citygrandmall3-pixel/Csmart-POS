// إدارة الكاشيرين وصلاحياتهم — مصدر واحد للأحداث والبيانات.
const cashierDefaultPermissions = {
  can_sell: true, can_open_session: true, can_hold_sale: true,
  can_cancel_draft: true, can_view_own_reports: true,
  can_apply_discount: false, max_discount_pct: 0,
  can_view_stock: false, can_view_others_sessions: false
};

function cashierParsePermissions(value) {
  try {
    const parsed = typeof value === 'string' ? JSON.parse(value || '{}') : (value || {});
    return { ...cashierDefaultPermissions, ...(parsed && typeof parsed === 'object' ? parsed : {}) };
  } catch (_) { return { ...cashierDefaultPermissions }; }
}
function cashierSetPermissions(value) {
  const p = cashierParsePermissions(value);
  const map = { can_sell:'cPermCanSell', can_open_session:'cPermOpenSession', can_hold_sale:'cPermHoldSale', can_cancel_draft:'cPermCancelDraft', can_view_own_reports:'cPermOwnReports', can_apply_discount:'cPermDiscount', can_view_stock:'cPermViewStock', can_view_others_sessions:'cPermOtherSessions' };
  Object.entries(map).forEach(([key,id]) => { const el=document.getElementById(id); if(el) el.checked = p[key] === true || p[key] === 1 || p[key] === '1'; });
  const max = document.getElementById('cPermMaxDiscountPct');
  if (max) max.value = String(Math.max(0, Math.min(100, Number(p.max_discount_pct) || 0)));
  cashierRefreshDiscountLimit();
}
function cashierReadPermissions() {
  const ids = { can_sell:'cPermCanSell', can_open_session:'cPermOpenSession', can_hold_sale:'cPermHoldSale', can_cancel_draft:'cPermCancelDraft', can_view_own_reports:'cPermOwnReports', can_apply_discount:'cPermDiscount', can_view_stock:'cPermViewStock', can_view_others_sessions:'cPermOtherSessions' };
  const p = {};
  Object.entries(ids).forEach(([key,id]) => { p[key] = !!document.getElementById(id)?.checked; });
  const max = Number(document.getElementById('cPermMaxDiscountPct')?.value || 0);
  if (!Number.isFinite(max) || max < 0 || max > 100) throw new Error('نسبة الخصم يجب أن تكون بين 0 و100');
  p.max_discount_pct = p.can_apply_discount ? max : 0;
  return p;
}
function cashierRefreshDiscountLimit() {
  const enabled = !!document.getElementById('cPermDiscount')?.checked;
  const input = document.getElementById('cPermMaxDiscountPct');
  if (input) input.disabled = !enabled;
}
function cashierModal(show) {
  const m=document.getElementById('cashierModal');
  if (!m) return;
  if (show) { document.body.appendChild(m); m.style.display='flex'; m.style.position='fixed'; }
  else m.style.display='none';
}
function hideCashierModal() { cashierModal(false); }
function openCashierModal() {
  document.getElementById('cashierModalTitle').textContent='➕ إضافة كاشير جديد';
  document.getElementById('cEditId').value='';
  document.getElementById('cUsername').value='';
  document.getElementById('cPassword').value='';
  document.getElementById('cFullName').value='';
  document.getElementById('cPhone').value='';
  document.getElementById('cPwNote').textContent='كلمة المرور مطلوبة للإضافة';
  cashierSetPermissions(cashierDefaultPermissions);
  cashierModal(true);
}
async function loadCashiers() {
  const body=document.getElementById('cashiersBody');
  if (!body) return;
  try {
    const data=await api('/api/cashiers');
    const rows=data.cashiers || [];
    body.innerHTML=rows.length ? rows.map(c=>`<tr><td>${Number(c.id)}</td><td>${esc(c.username||'')}</td><td>${esc(c.full_name||'')}</td><td>${c.is_active?'✅ نشط':'⛔ معطّل'}</td><td><button type="button" onclick="editCashier(${Number(c.id)})">✏️ تعديل</button> <button type="button" onclick="toggleCashier(${Number(c.id)})">${c.is_active?'تعطيل':'تنشيط'}</button> <button type="button" onclick="deleteCashier(${Number(c.id)})">🗑️</button></td></tr>`).join('') : '<tr><td colspan="5" style="text-align:center;padding:12px">لا يوجد كاشيرون بعد</td></tr>';
  } catch(e) { body.innerHTML=`<tr><td colspan="5" style="color:#c00">${esc(e.message)}</td></tr>`; }
}
async function editCashier(id) {
  try {
    const data=await api('/api/cashiers');
    const c=(data.cashiers||[]).find(x=>Number(x.id)===Number(id));
    if (!c) throw new Error('الكاشير غير موجود');
    document.getElementById('cashierModalTitle').textContent='✏️ تعديل الكاشير';
    document.getElementById('cEditId').value=c.id;
    document.getElementById('cUsername').value=c.username||'';
    document.getElementById('cPassword').value='';
    document.getElementById('cFullName').value=c.full_name||'';
    document.getElementById('cPhone').value=c.phone||'';
    document.getElementById('cPwNote').textContent='اترك كلمة المرور فارغة للإبقاء عليها';
    cashierSetPermissions(c.permissions_json);
    cashierModal(true);
  } catch(e) { alert(e.message); }
}
let cashierSaving=false;
async function saveCashier() {
  if (cashierSaving) return;
  const btn=document.getElementById('btnSaveCashier');
  const id=document.getElementById('cEditId').value;
  const username=document.getElementById('cUsername').value.trim().toLowerCase();
  const password=document.getElementById('cPassword').value;
  const full_name=document.getElementById('cFullName').value.trim();
  const phone=document.getElementById('cPhone').value.trim();
  if (username.length<3) return alert('اسم المستخدم 3 أحرف على الأقل');
  if (!full_name) return alert('الاسم الكامل مطلوب');
  if (!id && !password) return alert('كلمة المرور مطلوبة');
  let permissions;
  try { permissions=cashierReadPermissions(); } catch(e) { return alert(e.message); }
  const payload={username,full_name,phone,permissions};
  if (password) payload.password=password;
  cashierSaving=true; if(btn) btn.disabled=true;
  try {
    await api(id?`/api/cashiers/${id}`:'/api/cashiers',{method:id?'PUT':'POST',body:JSON.stringify(payload)});
    hideCashierModal(); await loadCashiers(); alert('تم حفظ بيانات الكاشير وصلاحياته');
  } catch(e) { alert('تعذر الحفظ: '+e.message); }
  finally { cashierSaving=false; if(btn) btn.disabled=false; }
}
async function toggleCashier(id) {
  if (!confirm('هل تريد تغيير حالة هذا الكاشير؟')) return;
  try { await api(`/api/cashiers/${id}/toggle`,{method:'POST',body:'{}'}); await loadCashiers(); }
  catch(e) { alert(e.message); }
}
async function deleteCashier(id) {
  if (!confirm('تأكيد حذف الكاشير؟ إذا كان له سجل ورديات فسيتم تعطيله بدلاً من الحذف.')) return;
  try { const d=await api(`/api/cashiers/${id}`,{method:'DELETE'}); alert(d.message||'تم'); await loadCashiers(); }
  catch(e) { alert(e.message); }
}
document.addEventListener('DOMContentLoaded',()=>{
  const add=document.getElementById('btnAddCashier'); if(add) add.addEventListener('click',openCashierModal);
  const cancel=document.getElementById('btnCancelCashier'); if(cancel) cancel.addEventListener('click',hideCashierModal);
  const save=document.getElementById('btnSaveCashier'); if(save) save.addEventListener('click',saveCashier);
  const discount=document.getElementById('cPermDiscount'); if(discount) discount.addEventListener('change',cashierRefreshDiscountLimit);
  if(document.getElementById('cashiersBody')) loadCashiers();
});
