/* Csmart POS — نوافذ مركزية موحدة للتنبيه والتأكيد والإدخال */
(function () {
  'use strict';

  const queue = [];
  let activeItem = null;
  let currentOverlay = null;

  const types = {
    success: { title: 'تم بنجاح', icon: '✓', css: 'success' },
    warning: { title: 'تنبيه', icon: '⚠', css: 'warning' },
    error:   { title: 'حدث خطأ', icon: '✕', css: 'error' },
    info:    { title: 'إشعار', icon: 'ℹ', css: 'info' },
    confirm: { title: 'تأكيد العملية', icon: '?', css: 'warning' },
    prompt:  { title: 'إدخال البيانات', icon: '✎', css: 'info' }
  };

  function normalizeType(type) {
    const value = String(type || '').toLowerCase();
    if (['ok', 'success', 'نجاح'].includes(value)) return 'success';
    if (['warn', 'warning', 'تنبيه'].includes(value)) return 'warning';
    if (['err', 'error', 'danger', 'خطأ'].includes(value)) return 'error';
    if (['confirm', 'question', 'تأكيد'].includes(value)) return 'confirm';
    return 'info';
  }

  function inferType(message) {
    const text = String(message ?? '').trim();
    if (/(خطأ|تعذر|فشل|لا يمكن|غير قادر|لم يتم|غير موجود|انتهت الجلسة|مرفوض|غير متاح)/i.test(text)) return 'error';
    if (/(تم بنجاح|بنجاح|تمت|تم إنشاء|تم حفظ|تم تحديث|تم حذف|تم اعتماد|تم استيراد|اكتمل|نجح|نجحت|✅|✔)/i.test(text)) return 'success';
    if (/(تنبيه|تحذير|يرجى|من فضلك|اختر|أدخل|يجب|لا توجد|لا يوجد|غير صحيح|غير صالح|تأكد|اسمح)/i.test(text)) return 'warning';
    return 'info';
  }

  function settle(value) {
    const item = activeItem;
    if (!item) return;
    if (currentOverlay) currentOverlay.remove();
    currentOverlay = null;
    activeItem = null;
    document.removeEventListener('keydown', handleKeydown, true);
    if (typeof item.resolve === 'function') item.resolve(value);
    showNext();
  }

  function handleKeydown(event) {
    if (!activeItem || !currentOverlay) return;
    const focusables = Array.from(currentOverlay.querySelectorAll('button, input')).filter(el => !el.disabled);
    if (event.key === 'Tab' && focusables.length) {
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      return;
    }
    if (event.key === 'Escape') {
      event.preventDefault(); event.stopPropagation();
      settle(activeItem.kind === 'confirm' ? false : activeItem.kind === 'prompt' ? null : undefined);
    } else if (event.key === 'Enter') {
      if (activeItem.kind === 'prompt' && document.activeElement?.tagName === 'INPUT') {
        event.preventDefault(); event.stopPropagation(); settle(currentOverlay.querySelector('.csmart-notice-input').value);
      } else if (activeItem.kind === 'confirm') {
        event.preventDefault(); event.stopPropagation();
        settle(currentOverlay.querySelector('.csmart-notice-cancel') === document.activeElement ? false : true);
      } else if (activeItem.kind === 'notice') {
        event.preventDefault(); event.stopPropagation(); settle(undefined);
      }
    }
  }

  function showNext() {
    if (activeItem || !queue.length || !document.body) return;
    const item = queue.shift();
    activeItem = item;
    const meta = item.kind === 'notice' ? (types[item.type] || types.info) : types[item.kind];

    const overlay = document.createElement('div');
    overlay.className = 'csmart-notice-overlay';
    overlay.setAttribute('dir', 'rtl');

    const dialog = document.createElement('section');
    dialog.className = `csmart-notice-dialog csmart-notice-${meta.css}`;
    dialog.setAttribute('role', item.kind === 'notice' ? 'alertdialog' : 'dialog');
    dialog.setAttribute('aria-modal', 'true');
    dialog.setAttribute('aria-labelledby', 'csmart-notice-title');
    dialog.setAttribute('tabindex', '-1');

    const header = document.createElement('div');
    header.className = 'csmart-notice-header';
    const icon = document.createElement('div');
    icon.className = 'csmart-notice-icon';
    icon.setAttribute('aria-hidden', 'true');
    icon.textContent = meta.icon;
    const title = document.createElement('h2');
    title.className = 'csmart-notice-title';
    title.id = 'csmart-notice-title';
    title.textContent = item.title || meta.title;
    header.append(icon, title);

    const message = document.createElement('div');
    message.className = 'csmart-notice-message';
    message.textContent = item.message;
    dialog.append(header, message);

    if (item.kind === 'prompt') {
      const input = document.createElement('input');
      input.type = 'text';
      input.className = 'csmart-notice-input';
      input.value = item.defaultValue == null ? '' : String(item.defaultValue);
      input.setAttribute('aria-label', item.message || 'إدخال البيانات');
      dialog.appendChild(input);
      item.input = input;
    }

    const footer = document.createElement('div');
    footer.className = 'csmart-notice-footer';
    if (item.kind === 'notice') {
      const ok = makeButton('موافق', 'csmart-notice-ok', () => settle(undefined));
      footer.appendChild(ok);
      item.focusTarget = ok;
    } else if (item.kind === 'confirm') {
      const cancel = makeButton('إلغاء', 'csmart-notice-cancel', () => settle(false));
      const ok = makeButton('متابعة', 'csmart-notice-ok', () => settle(true));
      footer.append(cancel, ok);
      item.focusTarget = cancel;
    } else {
      const cancel = makeButton('إلغاء', 'csmart-notice-cancel', () => settle(null));
      const ok = makeButton('موافق', 'csmart-notice-ok', () => settle(item.input.value));
      footer.append(cancel, ok);
      item.focusTarget = item.input;
    }
    dialog.appendChild(footer);
    overlay.appendChild(dialog);
    document.body.appendChild(overlay);
    currentOverlay = overlay;
    document.addEventListener('keydown', handleKeydown, true);
    (item.focusTarget || dialog).focus();
  }

  function makeButton(label, className, onClick) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = className;
    button.textContent = label;
    button.addEventListener('click', onClick);
    return button;
  }

  function enqueue(item) {
    queue.push(item);
    showNext();
  }

  function showAppNotification(message, type) {
    enqueue({ kind: 'notice', message: String(message ?? ''), type: type ? normalizeType(type) : inferType(message) });
  }

  function showAppConfirm(message) {
    return new Promise(resolve => enqueue({ kind: 'confirm', message: String(message ?? ''), resolve }));
  }

  function showAppPrompt(message, defaultValue) {
    return new Promise(resolve => enqueue({ kind: 'prompt', message: String(message ?? ''), defaultValue, resolve }));
  }

  window.showAppNotification = showAppNotification;
  window.showAppConfirm = showAppConfirm;
  window.showAppPrompt = showAppPrompt;
  window.CSMART_NOTIFICATIONS_READY = true;
  window.alert = function (message) { showAppNotification(message, inferType(message)); };
})();
