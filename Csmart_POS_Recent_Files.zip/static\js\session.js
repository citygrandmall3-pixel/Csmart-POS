// إدارة هوية الكاشير والوردية — الخادم هو مصدر الصلاحيات النهائي.
var currentSession = null;
var sessionCheckInterval = null;
window.currentCashier = null;

function sessionEl(id) { return document.getElementById(id); }
function sessionNumber(v) { const n=Number(v||0); return Number.isFinite(n)?n:0; }
function sessionMoney(v) { return typeof fmt==='function' ? fmt(v) : sessionNumber(v).toFixed(2); }
function sessionPermissions(value) {
  try { return typeof value==='string' ? JSON.parse(value||'{}') : (value||{}); } catch(_) { return {}; }
}
function sessionShow(id) {
  const el=sessionEl(id); if(!el) return;
  document.body.appendChild(el); el.style.position='fixed'; el.style.display='flex'; el.style.zIndex='999999';
}
function sessionHide(id) { const el=sessionEl(id); if(el) el.style.display='none'; }
function sessionMessage(message) { if(typeof toast==='function') toast(message,'error'); else alert(message); }

async function checkSession() {
  try {
    const data=await api('/api/cashier-sessions/current');
    if(data.ok && data.session) {
      currentSession=data.session;
      window.currentCashier=data.session.cashier_name?{id:data.session.cashier_id||null,name:data.session.cashier_name,permissions:sessionPermissions(data.session.cashier_permissions)}:{id:null,name:data.session.user_name||'',permissions:{can_sell:true,can_open_session:true,can_hold_sale:true,can_cancel_draft:true,can_view_own_reports:true,can_apply_discount:true,max_discount_pct:100,can_view_stock:true,can_view_others_sessions:true}};
      applyCashierPermissions();
      renderSessionBar(); sessionHide('sessionOpenModal');
      const bar=sessionEl('sessionBar'); if(bar) bar.style.display='flex';
      if(!sessionCheckInterval) sessionCheckInterval=setInterval(refreshSessionBar,30000);
    } else {
      currentSession=null; window.currentCashier=null;
      applyCashierPermissions();
      const bar=sessionEl('sessionBar'); if(bar) bar.style.display='none';
      if(sessionCheckInterval) { clearInterval(sessionCheckInterval); sessionCheckInterval=null; }
      openSessionOpenModal();
    }
  } catch(e) { console.error('تعذر التحقق من الوردية:',e); }
}
function renderSessionBar() {
  if(!currentSession) return;
  const s=currentSession;
  const vals={sessOpenedAt:s.opened_at||'-',sessInvCount:s.invoice_count||0,sessTotalSales:sessionMoney(s.total_sales),sessExpectedCash:sessionMoney(s.expected_cash)};
  Object.entries(vals).forEach(([id,val])=>{const el=sessionEl(id);if(el)el.textContent=val;});
}
async function refreshSessionBar() {
  try {
    const data=await api('/api/cashier-sessions/current');
    if(data.ok && data.session) { currentSession=data.session; renderSessionBar(); }
    else { currentSession=null; await checkSession(); }
  } catch(e) { console.warn('تعذر تحديث ملخص الوردية',e); }
}
function openSessionOpenModal() {
  const cash=sessionEl('sessOpeningCash'),notes=sessionEl('sessOpenNotes');
  if(cash) cash.value='0'; if(notes) notes.value='';
  sessionShow('sessionOpenModal');
}
async function confirmOpenSession() {
  const username=(sessionEl('sessUsername')?.value||'').trim().toLowerCase();
  const password=sessionEl('sessPassword')?.value||'';
  const cash=sessionNumber(sessionEl('sessOpeningCash')?.value);
  const notes=(sessionEl('sessOpenNotes')?.value||'').trim();
  if(!username || !password) return alert('أدخل اسم المستخدم وكلمة المرور');
  if(!Number.isFinite(cash) || cash<0) return alert('أدخل رصيداً افتتاحياً صحيحاً');
  const button=sessionEl('sessionOpenModal')?.querySelector('button[onclick="confirmOpenSession()"]');
  if(button) button.disabled=true;
  try {
    const auth=await api('/api/cashier-login',{method:'POST',body:JSON.stringify({username,password})});
    if(!auth.ok || !auth.cashier) throw new Error(auth.error||'بيانات الكاشير غير صحيحة');
    window.currentCashier=auth.cashier;
    applyCashierPermissions();
    await api('/api/cashier-sessions/open',{method:'POST',body:JSON.stringify({opening_cash:cash,notes:notes})});
    const user=sessionEl('sessUsername'),pass=sessionEl('sessPassword'); if(user)user.value=''; if(pass)pass.value='';
    sessionHide('sessionOpenModal');
    await checkSession();
    alert('تم فتح الوردية للكاشير: '+(auth.cashier.full_name||auth.cashier.username));
  } catch(e) { alert('تعذر فتح الوردية: '+e.message); }
  finally { if(button) button.disabled=false; }
}
function openSessionCloseModal() {
  if(!currentSession) return;
  const s=currentSession;
  const values={closeOpeningCash:sessionMoney(s.opening_cash),closeCashSales:sessionMoney(s.cash_sales),closeTotalSales:sessionMoney(s.total_sales),closeExpectedCash:sessionMoney(s.expected_cash),closeInvCount:s.invoice_count||0};
  Object.entries(values).forEach(([id,val])=>{const el=sessionEl(id);if(el)el.textContent=val;});
  const actual=sessionEl('sessActualCash'),notes=sessionEl('sessCloseNotes');
  if(actual) { actual.value=sessionNumber(s.expected_cash).toFixed(2); actual.oninput=updateSessionDiff; }
  if(notes) notes.value='';
  updateSessionDiff(); sessionShow('sessionCloseModal');
}
function updateSessionDiff() {
  if(!currentSession) return;
  const actual=sessionNumber(sessionEl('sessActualCash')?.value),expected=sessionNumber(currentSession.expected_cash),diff=actual-expected,box=sessionEl('sessDiffBox');
  if(!box) return;
  if(Math.abs(diff)<0.01) { box.textContent='✅ مطابق تماماً'; box.style.background='#d4edda'; box.style.color='#155724'; }
  else if(diff>0) { box.textContent='⚠️ زيادة: '+sessionMoney(diff); box.style.background='#fff3cd'; box.style.color='#856404'; }
  else { box.textContent='❌ عجز: '+sessionMoney(Math.abs(diff)); box.style.background='#f8d7da'; box.style.color='#721c24'; }
}
function hideSessionCloseModal(){sessionHide('sessionCloseModal');}
async function confirmCloseSession() {
  if(!currentSession) return;
  const actual=sessionNumber(sessionEl('sessActualCash')?.value),notes=(sessionEl('sessCloseNotes')?.value||'').trim();
  if(!Number.isFinite(actual)||actual<0) return alert('أدخل النقد الفعلي بشكل صحيح');
  const expected=sessionNumber(currentSession.expected_cash),diff=actual-expected;
  if(Math.abs(diff)<0.01) { if(!confirm('تأكيد إغلاق الوردية؟\n\nالنقد متطابق تماماً.')) return; await doCloseSession(actual,notes); }
  else await openSessionReviewModal(actual,expected,diff,notes);
}
async function doCloseSession(actual,notes) {
  if(!currentSession) return;
  try {
    const result=await api('/api/cashier-sessions/'+currentSession.id+'/close',{method:'POST',body:JSON.stringify({actual_cash:actual,notes:notes})});
    if(!result.ok) throw new Error(result.error||'فشل إغلاق الوردية');
    sessionHide('sessionCloseModal'); sessionHide('sessionReviewModal');
    currentSession=null; window.currentCashier=null;
    if(sessionCheckInterval) { clearInterval(sessionCheckInterval); sessionCheckInterval=null; }
    const bar=sessionEl('sessionBar'); if(bar)bar.style.display='none';
    alert('تم إغلاق الوردية بنجاح. أدخل بيانات الكاشير لبدء وردية جديدة.');
    await checkSession();
  } catch(e) { alert('تعذر إغلاق الوردية: '+e.message); }
}
function hideSessionReviewModal(){sessionHide('sessionReviewModal');}
async function openSessionReviewModal(actual,expected,diff,notes) {
  const el=sessionEl('sessionReviewModal'); if(!el) return alert('نافذة مراجعة الوردية غير موجودة');
  const vals={revExpected:sessionMoney(expected),revActual:sessionMoney(actual),revDiff:(diff>0?'+':'')+sessionMoney(diff),revInvCount:0};
  Object.entries(vals).forEach(([id,val])=>{const node=sessionEl(id);if(node)node.textContent=val;});
  const dif=sessionEl('revDiff'); if(dif)dif.style.color=diff>0?'#856404':'#721c24';
  const body=sessionEl('revInvBody'); if(body)body.innerHTML='<tr><td colspan="4" style="text-align:center;padding:10px">تفاصيل الفواتير غير متاحة لهذه الصلاحية</td></tr>';
  try {
    const data=await api('/api/cashier-sessions/'+currentSession.id);
    const invoices=data.invoices||[];
    const count=sessionEl('revInvCount'); if(count)count.textContent=invoices.length;
    if(body) body.innerHTML=invoices.length?invoices.map(inv=>`<tr><td style="padding:6px">${Number(inv.id)}</td><td style="padding:6px">${esc(inv.invoice_no||'')}</td><td style="padding:6px">${sessionMoney(inv.grand_total)}</td><td style="padding:6px">${inv.payment_method==='cash'?'نقدي':inv.payment_method==='credit'?'آجل':esc(inv.payment_method||'')}</td></tr>`).join(''):'<tr><td colspan="4" style="text-align:center;padding:10px">لا توجد فواتير</td></tr>';
  } catch(e) { console.info('تفاصيل الوردية غير متاحة لهذه الصلاحية'); }
  const reason=sessionEl('revReason'); if(reason)reason.value='';
  window._pendingClose={actual,notes}; sessionShow('sessionReviewModal');
}
async function confirmReviewAndClose() {
  const reason=(sessionEl('revReason')?.value||'').trim();
  if(!reason) return alert('يجب إدخال سبب الفرق');
  const pending=window._pendingClose||{};
  await doCloseSession(pending.actual,(pending.notes?pending.notes+' | ':'')+'سبب الفرق: '+reason);
}
function applyCashierPermissions() {
  const p=(window.currentCashier&&window.currentCashier.permissions)||{};
  const allowed=(key,defaultValue=false)=>p[key]===true||p[key]===1||p[key]==='1'||p[key]==='true'||(p[key]===undefined&&defaultValue);
  const canSell=allowed('can_sell',false),canHold=allowed('can_hold_sale',false),canCancel=allowed('can_cancel_draft',false),canHistory=allowed('can_view_own_reports',false),canDiscount=allowed('can_apply_discount',false);
  const controls=[['btnHoldSale',canHold],['btnShowHeldSales',canHold],['btnOpenReturns',canSell],['btnOpenDelivery',canSell],['btnPendingDelivery',canSell],['posShowSalesHistoryButton',canHistory],['btnPartialReturn',canSell],['btnFullReturn',canSell]];
  controls.forEach(([id,show])=>{const el=sessionEl(id);if(el)el.style.display=show?'':'none';});
  const search=sessionEl('posProductSearch'); if(search)search.disabled=!canSell;
  const discount=sessionEl('pmDiscount'); const discountValue=sessionEl('pmDiscountValue');
  if(discount)discount.disabled=!canDiscount; if(discountValue)discount.disabled=!canDiscount;
  if(!canCancel) document.querySelectorAll('[data-cashier-cancel-draft]').forEach(el=>el.style.display='none');
}

document.addEventListener('DOMContentLoaded',()=>{checkSession();});
