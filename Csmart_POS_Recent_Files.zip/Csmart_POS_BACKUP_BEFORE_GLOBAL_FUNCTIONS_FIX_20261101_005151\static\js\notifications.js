/* إشعارات Csmart POS الموحدة — نافذة مركزية تتطلب موافقة المستخدم */
(function () {
  'use strict';

  const queue = [];
  let active = false;
  let currentOverlay = null;

  const types = {
    success: { title: 'تم بنجاح', icon: '✓', css: 'success' },
    warning: { title: 'تنبيه', icon: '⚠', css: 'warning' },
    error:   { title: 'حدث خطأ', icon: '✕', css: 'error' },
    info:    { title: 'إشعار', icon: 'ℹ', css: 'info' }
  };

  function normalizeType(type) {
    const value = String(type || '').toLowerCase();
    if (['ok', 'success', 'نجاح'].includes(value)) return 'success';
    if (['warn', 'warning', 'تنبيه'].includes(value)) return 'warning';
    if (['err', 'error', 'danger', 'خطأ'].includes(value)) return 'error';
    return 'info';
  }

  function inferType(message) {
    const text = String(message ?? '').trim();
    if (/(خطأ|تعذر|فشل|لا يمكن|غير قادر|لم يتم|غير موجود|انتهت الجلسة|مرفوض|غير متاح)/i.test(text)) return 'error';
    if (/(تم بنجاح|بنجاح|تمت|تم إنشاء|تم حفظ|تم تحديث|تم حذف|تم اعتماد|تم استيراد|اكتمل|نجح|نجحت|✅|✔)/i.test(text)) return 'success';
    if (/(تنبيه|تحذير|يرجى|من فضلك|اختر|أدخل|يجب|لا توجد|لا يوجد|غير صحيح|غير صالح|تأكد|اسمح)/i.test(text)) return 'warning';
    return 'warning';
  }

  function closeCurrent() {
    if (!active) return;
    if (currentOverlay) currentOverlay.remove();
    currentOverlay = null;
    active = false;
    document.removeEventListener('keydown', handleKeydown, true);
    showNext();
  }

  function handleKeydown(event) {
    if (event.key === 'Tab') {
      event.preventDefault();
      if (currentOverlay) currentOverlay.querySelector('.csmart-notice-ok')?.focus();
      return;
    }
    if (event.key === 'Escape' || event.key === 'Enter') {
      event.preventDefault();
      event.stopPropagation();
      closeCurrent();
    }
  }

  function showNext() {
    if (active || !queue.length || !document.body) return;
    const item = queue.shift();
    const meta = types[item.type] || types.info;
    active = true;

    const overlay = document.createElement('div');
    overlay.className = 'csmart-notice-overlay';
    overlay.setAttribute('dir', 'rtl');

    const dialog = document.createElement('section');
    dialog.className = `csmart-notice-dialog csmart-notice-${meta.css}`;
    dialog.setAttribute('role', 'alertdialog');
    dialog.setAttribute('aria-modal', 'true');
    dialog.setAttribute('aria-labelledby', 'csmart-notice-title');
    dialog.setAttribute('aria-describedby', 'csmart-notice-message');
    dialog.setAttribute('tabindex', '-1');

    const header = document.createElement('div');
    header.className = 'csmart-notice-header';

    const icon = document.createElement('div');
    icon.className = 'csmart-notice-icon';
    icon.setAttribute('aria-hidden', 'true');
    icon.textContent = meta.icon;

    const title = document.createElement('h2');
    title.className = 'csmart-notice-title';
    title.id = 'csmart-notice-title';
    title.textContent = meta.title;

    const message = document.createElement('div');
    message.className = 'csmart-notice-message';
    message.id = 'csmart-notice-message';
    message.textContent = item.message;

    const footer = document.createElement('div');
    footer.className = 'csmart-notice-footer';

    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'csmart-notice-ok';
    button.textContent = 'موافق';
    button.addEventListener('click', closeCurrent);

    header.append(icon, title);
    footer.appendChild(button);
    dialog.append(header, message, footer);
    overlay.appendChild(dialog);
    document.body.appendChild(overlay);

    currentOverlay = overlay;
    document.addEventListener('keydown', handleKeydown, true);
    button.focus();
  }

  function showAppNotification(message, type) {
    queue.push({ message: String(message ?? ''), type: type ? normalizeType(type) : inferType(message) });
    showNext();
  }

  window.showAppNotification = showAppNotification;
  window.alert = function (message) {
    showAppNotification(message, inferType(message));
  };
})();
